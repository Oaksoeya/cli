---
name: Gitcoin Bounty
about: Create a new Gitcoin Bounty
title: ''
labels: bounty
assignees: ''

---

### Project:
Lorem ipsum description

### Submission Requirements:
- The project must be open source. 
- Your project must be connected to a blockchain domain (e.g. create a web app stored on IPFS and add the hash to your domain). 
  - If you need a blockchain domain for your project reach out to one of the community managers in our [Telegram](https://t.me/unstoppabledev)

### Bounty:
$/ETH

### Deadline:
TBD

### Have questions? 
Join our developer channel on [Discord!](https://discord.gg/b6ZVxSZ9Hn)
